<div class="container">
    <div class="col-xs-12 col-md-offset-4 col-md-4">
        <div class="panel panel-group">
            <div class="panel-body text-center">
               Here should go plugin notices!
            </div>
        </div>
    </div>
</div>




