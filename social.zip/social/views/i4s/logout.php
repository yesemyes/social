<?php 
session_destroy();
global $current_user, $wpdb;
$table_name = $wpdb->prefix . "persons";
get_currentuserinfo();
$check_token = $wpdb->get_results("SELECT * FROM $table_name", OBJECT); 
if( $check_token != null ) {
    $query = $wpdb->query("UPDATE $table_name SET token = '', user_id = '$current_user->ID', username = '', password = '' WHERE ID = ".$check_token[0]->ID);
}
?>
<script type="text/javascript">
	window.location.href = "admin.php?page=iio4social-settings";
</script>