<div class="posts-container">
    <div class="inbox">
        <div class="panel">
            <div class="panel-body">
                This is the dashboard. Here we should show global information about plugin (for example a video of how it works),
                or some kind of statistic. However content of this page will be ready after lunching plugin v1!
            </div>
        </div>
    </div>
</div>
