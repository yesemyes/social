jQuery(document).ready(function($)
{
    $('.deleteAccount').on('click', function(e)
    {
        var url = "/wp-admin/admin-ajax.php";
        var dataId = $(this).attr('data-id');
        var token = $(this).attr('data-token');
        $.ajax({
            url: url,
            type: 'POST',
            data: {
                action: 'delete_social_account',
                id: dataId,
                access_token: token
            },
            success: function( msg ) {
                if ( msg === 'success' ) {
                    $(".loader").css({"display":"block"});
                    setInterval(function() {
                    window.location.reload();
                    }, 1500);
                }else if( msg === 'failed' ){
                    alert('Failed');
                }else{
                    alert('Error');
                }
            },
            error: function( data ) {
                console.log(data);
                alert('error');
            },
        });
      return false;
    });

    var block = $("#sharePost").find(".b2s-post-item");
    $(document).on("click", ".noconnected", function()
    {
        var noconnected = $(this).val();
        $(this).attr("class", "connected");
        $(this).attr("name", "connected[]");
        $( block ).each(function( index ) {
            $("textarea[data-post-title='"+noconnected+"']").attr("name", "postTitle[]");
            $("input[data-post-content='"+noconnected+"']").attr("name", "postContent[]");
            $("input[data-soc='"+noconnected+"']").attr("name", "token_soc[]");
            $("input[data-soc-sec='"+noconnected+"']").attr("name", "token_soc_sec[]");
            $("div[data-network-name='"+noconnected+"']").css({"display":"block"});
        });
    });

    $(document).on("click", ".connected", function()
    {
        var connected = $(this).val();
        $(this).attr("class", "noconnected");
        $(this).attr("name", "noconnected[]");
        $( block ).each(function( index ) {
            $("textarea[data-post-title='"+connected+"']").attr("name", "asd[]");
            $("input[data-post-content='"+connected+"']").attr("name", "asd[]");
            $("input[data-soc='"+connected+"']").attr("name", "asd[]");
            $("input[data-soc-sec='"+connected+"']").attr("name", "asd[]");
            $("div[data-network-name='"+connected+"']").css({"display":"none"});
        });
    });

});